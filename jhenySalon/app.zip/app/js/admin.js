Vue.component('admin',
{
    template : `<div class="animated zoomIn">


                     <!-------------------------------------------
                            Getting Salons From FireBase
                     -------------------------------------------->
                     <br><br><h1 style="text-align:center;background:rgba(0,0,0,0.7);color:white;padding:20px;">Salons</h1>
                     <table class="pending"">
                     <thead>
                         <tr>
                             <th>Salon Name</th>
                             <th>Contact Number</th>
                             <th>Address</th>
                             <th>Time Table</th>
                             <th>Web Link</th>
                         </tr>
                     </thead>
                     <tbody>
                         <tr v-for="salon in salons">
                             <td>{{ salon.salonName }}</td>
                             <td>{{ salon.contactNumber }}</td>
                             <td>{{ salon.address }}</td>
                             <td>{{ salon.timetable }}</td>
                             <td>{{ salon.weblink }}</td>                             
                         </tr>
                     </tbody>
                 </table>
                 
                 
                     <!-------------------------------------------
                            Getting Requests From FireBase
                     -------------------------------------------->
                     <br><br><h1 style="text-align:center;background:rgba(0,0,0,0.7);color:white;padding:20px;">Requests</h1>
                     <table class="pending"">
                     <thead>
                         <tr>
                             <th>Salon Name</th>
                             <th>Contact Number</th>
                             <th>Address</th>
                             <th>Time Table</th>
                             <th>Web Link</th>
                             <th>Move To Active Salons</th>
                         </tr>
                     </thead>
                     <tbody>
                         <tr v-for="(salon,index) in requests">
                             <td>{{ salon.salonName }}</td>
                             <td>{{ salon.contactNumber }}</td>
                             <td>{{ salon.address }}</td>
                             <td>{{ salon.timetable }}</td>
                             <td>{{ salon.weblink }}</td>   
                             <td>
                               <a @click="postSalons" href="javascript:;"><i :id="index" class="material-icons">cloud_upload</i></a>
                             </td>   
                             
                         </tr>
                     </tbody>
                 </table>                 


                </div>`,
    data()
      {
         return {

                 salons : "",
               requests : "",
                   move : ""

                }
      },
    
    methods : 
      {

          postSalons(event)
           {


                 this.move = event.srcElement.id;
                 
                 let del = this.requests[this.move].unique;
                 
                 const refetch = () => this.getData();
                 

                 this.$http.post('https://reservation-system-69ff9.firebaseio.com/salons.json?auth='+rest,
                 {
                 
                       "address" : this.requests[this.move].address,
                 "contactNumber" : this.requests[this.move].contactNumber,
                     "salonName" : this.requests[this.move].salonName,
                     "timetable" : this.requests[this.move].timetable,
                       "weblink" : this.requests[this.move].weblink
                 }).then(function(data)
                  {
                      this.$http.delete('https://reservation-system-69ff9.firebaseio.com/salonsRequests/'+del+'.json').then(function(data){});
                      
                      setTimeout(function(){
                      
                      refetch();
                          
                      },1000);
                      

                  });


           },
           getData()
           {
                this.$http.get('https://reservation-system-69ff9.firebaseio.com/salons.json?auth='+rest).then(function(data)
                {
                      this.salons = Object.values(data.body);
                });
                
                this.$http.get('https://reservation-system-69ff9.firebaseio.com/salonsRequests.json').then(function(data)
                {
                    
                      return data.json();
                    
                }).then(function(data)
                      {
                          let requests = [];
                          for(let key in data)
                           {
                               data[key].unique = key; // Adding the property (unique) in every object & assigning the value of objects,key
                               
                               requests.push(data[key]);
                           }
                           this.requests = requests; 
                       });                      
              
                
           },
 
      },
   created()
      {
        
        const data = () => this.getData();
        
        setTimeout(function(){
        
         data();
        
        },2000); 
        
        
      }

});