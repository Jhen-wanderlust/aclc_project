Vue.component('contact',
 {
    props : ["id"],
 template : `<div :class="'animated fadeInRight component contact ' + id">
    
              <i class="material-icons-two-tone">phone</i>
              <span>0039 3890608115</span><hr class="hrhr">

              <i class="material-icons-two-tone">alternate_email</i>
              <span>Sarmadikram4@gmail.com</span><hr class="hrhr">

              <i class="material-icons-two-tone">location_city</i>
              <span>Via IV Novembre 6984, Milano</span><hr class="hrhr">
 
 </div>` 
 });