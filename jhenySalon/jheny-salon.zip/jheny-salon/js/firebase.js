  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyAmSAFGBrBO10qZjKYnHansy5vCKcfTzIo",
    authDomain: "reservation-system-69ff9.firebaseapp.com",
    databaseURL: "https://reservation-system-69ff9.firebaseio.com",
    projectId: "reservation-system-69ff9",
    storageBucket: "reservation-system-69ff9.appspot.com",
    messagingSenderId: "148820588827",
    appId: "1:148820588827:web:0f142e3880ab4c3b993bbe"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);