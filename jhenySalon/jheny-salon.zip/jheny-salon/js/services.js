Vue.component('services',
{
       props : ["id"],
    template : `<div :class="'animated fadeInRight component ' + id">
                  <div class="add-option" @click="openAdd()">Add Services</div>
                  <div id="add" class="animated fadeIn" v-show="open">
                      <div class="service-info"><input type="text" class="in" v-model="serv[0]" placeholder="Name of Category"></div>
                      <div class="service-info"><input type="text" class="in" v-model="serv[1]" placeholder="Name of Service"></div> 
                      <div class="service-info"><input type="text" class="in" v-model="serv[2]" placeholder="Price of Service"> </div> 
                      <br>
                      <button @click="addService" style="margin:0 auto; display:block;" name="action" class="btn waves-effect waves-light center">
                        <i class="material-icons right">send</i>
                        Add Service
                      </button>
                      <div id="closeme" @click="openAdd()">X</div>
                  </div>
          
                  
                  
                  <br><br><br><br><br><br>
                      <div class="service-main-container" v-show="!open">
                        <div class="animated zoomIn main-service" v-for="cat in categories">
                          <h1 class="cat-title">{{ cat }}</h1>
                           <div class="service-info" v-for="service in services" v-if="cat == service.category">
                             {{ service.name }} : php {{ service.price }}
                              <span @click="eliminate" id="closeme" :data-id="service.unique" style="
                               color: white;
                               font-size: 1.9rem;
                               margin-left: 20px;
                               padding: 20px;">X</span>                             
                              <hr class="cont-sep"> 
                           </div> 
                        </div>
                      </div>                  
               </div>`,
    data()
      {
          return {
                   
                   services : [],
                 categories : [],
                       open : false,
                       serv : []

                 }
      },
    methods :
     {
        openAdd()
         {

              this.open = !this.open;
         },
         
        addService()
         {
            if(this.serv[0].length > 0 &  this.serv[1].length != 0  &  this.serv[2].length != 0)
              {
        
                    let cat = this.serv[0].toLowerCase().trim();             
                    this.$http.post('https://reservation-system-69ff9.firebaseio.com/jheny-salon/services/.json?auth='+rest,
                                   {
                                    "category" : cat,
                                        "name" : this.serv[1],
                                       "price" : this.serv[2]
                                       
                                   }).then(function(data)
                                   {
                                     this.open = !this.open;
                                     this.serv[0] = "";
                                     this.serv[1] = "";
                                     this.serv[2] = "";
                                     this.fetcher();
                                   });
              }
         },

        fetcher()
         {
             // Fetching Data From FireBase
             this.$http.get('https://reservation-system-69ff9.firebaseio.com/jheny-salon/services.json').then(function(data)
              {
                   return data.json();
              }).then(function(data)
              {
                    let requests = [];
                  for(let key in data)
                   {
                       data[key].unique = key; // Adding the property (unique) in every object & assigning the value of objects,key
                       
                       requests.push(data[key]);
                     (this.categories.includes(data[key].category)) ? false : this.categories.push(data[key].category);
                   }
                   this.services = requests; 
              });
         },
         
        eliminate(e)
         {
            let unique = e.srcElement.dataset.id;
            
            let confirmation = confirm('Are You Sure You Want To Delete This Service!');
            
              if(confirmation == true)
               {
        
                    this.$http.delete("https://reservation-system-69ff9.firebaseio.com/jheny-salon/services/"+unique+".json?auth="+rest).then(function(data)
                     {
                         this.fetcher();
                     });                 
        
               }
              else
               {
                 return false;
               }
            

         }
    
    },
   created()
    {
        this.fetcher();
    }   

});